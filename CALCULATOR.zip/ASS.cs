﻿using System; 
namespace Class
{
    class Class
    {
static void Main(string[] args)
           {
var object1 = new Calculate();
string Op;
Console.WriteLine("Enter first number:");
 var first_num=Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Enter second number:");
 var second_mum =Convert.ToDouble(Console.ReadLine());
 Console.WriteLine("enter an operator");
 Opera=Console.ReadLine();

 
 if(Op=="+")
 {
Console.WriteLine(object1.Add(first_num,second_num));
 }
else if(Op=="-")
 {
Console.WriteLine(object1.substract(first_num,second_num));
 }
 else if(Op=="*")
 {
Console.WriteLine(object1.multiply(first_num,second_num));
 } 
 else if(Op=="/")
 {
Console.WriteLine(object1.divide(first_num,second_num));
 }
 else
 {
     Console.WriteLine("imposible calculation");
 }
Console.ReadKey();
           }
    }

}
    

   