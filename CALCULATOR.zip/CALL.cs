using System; 
namespace Class
{
    class Calculate
    
    {
        public double Add(double first_num,double second_num)
        {
    return (first_num + second_num;
        }
        public double substract( double first_num,double second_num)
        {
 return(first_num- second_num);
        }
        public double divide( double first_num,double second_num)
        {
            if(second_num !=0)
            return(first_num/second_num);
            else
            {
              throw new Exception("imposible");  
            }
        }
        public double multiply( double first_num,double second_num)
        {
return(first_num*second_num);
        }
    }
}
